'use strict'

module.exports = {

  dataCall: function() {
    return {
      "foo": "sample data",
      "bar": "additional sample data"
    }
  }

} // end exports
